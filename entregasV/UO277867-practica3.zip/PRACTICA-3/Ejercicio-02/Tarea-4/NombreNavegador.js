document.write(infoNavegador.nombre)
