document.write("<p>Version: ")
document.write(infoNavegador.version)
document.write("</p>")

document.write("<p>Plataforma: ")
document.write(infoNavegador.plataforma)
document.write("</p>")

document.write("<p>Vendedor: ")
document.write(infoNavegador.vendedor)
document.write("</p>")

document.write("<p>Agente de usuario: ")
document.write(infoNavegador.agente)
document.write("</p>")

document.write("<p>Java activado: ")
document.write(infoNavegador.javaActivo)
document.write("</p>")