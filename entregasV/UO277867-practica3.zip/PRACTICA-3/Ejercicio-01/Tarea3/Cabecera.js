var asignatura = new Object();
asignatura.nombre = "Software y estandares en la Web";
asignatura.titulacion = "Grado en Ingenieri­a Informatica del Software";
asignatura.centro = "Escuela de Ingenieri­a Informatica";
asignatura.universidad = "Universidad de Oviedo";
asignatura.curso = "2020-2021";
asignatura.estudiante = "Valentin Dumitru";
asignatura.email = "UO277867@uniovi.es"