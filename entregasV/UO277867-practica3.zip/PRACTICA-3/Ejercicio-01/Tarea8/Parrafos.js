document.write("<p>")
document.write(asignatura.curso)
document.write("</p>")

document.write("<p>")
document.write(asignatura.estudiante)
document.write("</p>")

document.write("<p>")
document.write(asignatura.email)
document.write("</p>")